﻿1- Run the "EaseUS hosts blocker.bat" file and when the process is complete, check if the following
values ​​are in the hosts file; if there are any that are not included, add the ones that are not
included yourself:


127.0.0.1	activation.easeus.com




*Note: The hosts file is located in the following directory:
%SystemRoot%\System32\drivers\etc

2- Install EaseUS Data Recovery Wizard.
download Link: https://drive.google.com/file/d/1goOtq6FaPxeIQRwMPF6cl7kOz4pp5UGW/view?usp=sharing

3- Copy the "(x-Bit) EDRW Patcher v1.1.exe" app suitable for the architecture of your OS to the
"EaseUS Data Recovery Wizard (x.x(if there is version))" installation directory and run it there;
otherwise, the patching process will not start.

4- Run the "EDRW v13 Activator v2.1.exe" app and click the [Activate] button, then when it asks where
EaseUS Data Recovery Wizard is installed, show the path to the exact installation directory of
"EaseUS Data Recovery Wizard (x.x(if there is version))" without any subfolders.

5- Enjoy! ;)

Now you can download the updated version of the software(free trial) from the official website and update the software manually. (No need to active it again)

